﻿var quotes = [
 'Your fortune: Godly Luck',
 'Your fortune: Reply hazy, try again',
 'Your fortune: Excellent Luck',
 'Your fortune: Good Luck',
 'Your fortune: Average Luck',
 'Your fortune: Bad Luck',
 'Your fortune: Good news will come to you by mail',
 'Your fortune: You will meet a dark handsome stranger',
 'Your fortune: Better not tell you now',
 'Your fortune: Outlook good',
 'Your fortune: Very Bad Luck',
 'Your fortune: le ebin dubs xDDDDDDDDDDD',
 'Your fortune: you gon\' get some dick',
 'Your fortune: ayy lmao',
 'Your fortune: (YOU ARE BANNED)',
 'Your fortune: Get Shrekt',
 'Your fortune: YOU JUST LOST THE GAME'

]

function newQuote() {
 var randomNumber = Math.floor(Math.random() * (quotes.lenght));
 document.getElementById('quoteDisplay').innerHTML = quotes[randomNumber];
}